APP CODING WEBSITE — NEW DESIGN

This version follows the same simple card-based design language as the
APP CODING EXAM HTML supplied by the user:
- blue gradient header
- rounded white cards
- compact mobile-first layout
- clear buttons and sections
- Bengali interface
- exact supplied APP CODING logo
- real App_Coding_1_5.apk download link

Upload ALL files to the ROOT of the GitHub Pages repository.
The APK download buttons point to:
./App_Coding_1_5.apk

If your domain is not https://www.appcoding.com/, update canonical/JSON-LD,
robots.txt and sitemap.xml before publishing.
